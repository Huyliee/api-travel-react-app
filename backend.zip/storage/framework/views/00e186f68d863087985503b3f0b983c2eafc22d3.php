<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Xác nhận đơn hàng</h1>

<p>Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn có số đơn: <?php echo e($order->id_order_tour); ?></p>

<!-- Hiển thị các thông tin khác về đơn hàng -->

</body>
</html><?php /**PATH D:\Học tập - STU\Luận văn\travel-reactjs-laravel\backend\resources\views/emails/order_confirmation.blade.php ENDPATH**/ ?>